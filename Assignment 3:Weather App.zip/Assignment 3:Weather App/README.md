# Verma Weather - Modern Weather Application

A beautiful, responsive weather application built with Next.js 16, React 19, and Tailwind CSS. Features real-time weather data, hourly and daily forecasts, interactive charts, and dynamic color theming based on temperature.

## 🌟 Features

- **Real-time Weather Data**: Current conditions with temperature, humidity, wind speed, visibility, and pressure
- **Hourly Forecast**: 12-hour detailed forecast with temperature, precipitation, humidity, and wind
- **Daily Forecast**: 7-day and 14-day extended forecasts
- **Interactive Charts**: Visualize temperature, humidity, precipitation, and wind trends over 24 hours
- **Dynamic Color Theming**: Automatic color palette selection based on temperature:
  - Blue: Cold (< 10°C)
  - Green: Cool (10-20°C)
  - Yellow: Warm (20-25°C)
  - Red: Hot (> 25°C)
- **Manual Theme Selection**: Override automatic theming with 5 color palettes
- **Location Search**: Search and switch between different locations worldwide
- **Animated UI**: Smooth animations and transitions using Framer Motion
- **Responsive Design**: Fully responsive layout that works on mobile, tablet, and desktop
- **Glassmorphism Design**: Modern UI with backdrop blur effects and transparency

## 🛠️ Tech Stack

- **Framework**: Next.js 16 (App Router)
- **React**: 19.2.0
- **Styling**: Tailwind CSS 4 with custom design tokens
- **Animations**: Framer Motion 12.23.24
- **Charts**: Recharts 3.3.0
- **Icons**: Lucide React 0.548.0
- **Font**: Poppins (Google Fonts)
- **Weather API**: Open-Meteo (Free, no API key required)

## 📋 Project Structure

\`\`\`
weather/
├── app/
│ ├── layout.tsx # Root layout with metadata and font setup
│ ├── page.tsx # Entry point component
│ ├── globals.css # Global styles and design tokens
│ └── loading.tsx # Loading state component
├── components/
│ ├── atoms/ # Smallest UI components
│ │ ├── weather-icon.tsx
│ │ ├── temperature-display.tsx
│ │ ├── weather-stat-card.tsx
│ │ ├── hourly-forecast-card.tsx
│ │ ├── daily-forecast-card.tsx
│ │ ├── weekly-forecast-item.tsx
│ │ ├── theme-color-button.tsx
│ │ ├── forecast-button.tsx
│ │ └── animated-weather-background.tsx
│ ├── molecules/ # Composite components
│ │ ├── search-input.tsx
│ │ ├── current-weather-display.tsx
│ │ ├── theme-color-picker.tsx
│ │ ├── hourly-forecast-list.tsx
│ │ ├── daily-forecast-grid.tsx
│ │ ├── weekly-forecast-list.tsx
│ │ └── forecast-tabs.tsx
│ ├── organisms/ # Complex feature components
│ │ ├── header.tsx
│ │ ├── current-weather-card.tsx
│ │ ├── chart-section.tsx
│ │ └── forecast-section.tsx
│ ├── templates/ # Page-level templates
│ │ └── weather-page-template.tsx
│ ├── ui/ # shadcn/ui components
│ └── theme-provider.tsx # Theme context provider
├── hooks/
│ ├── use-weather.ts # Custom hook for fetching weather data
│ ├── use-mobile.ts # Mobile detection hook
│ └── use-toast.ts # Toast notification hook
├── lib/
│ └── utils.ts # Utility functions (cn for class merging)
├── public/
│ ├── favicon.png
│ ├── placeholder-logo.png
│ ├── placeholder-logo.svg
│ └── placeholder.svg
├── styles/
│ └── globals.css # Additional global styles
├── package.json # Dependencies and scripts
├── tsconfig.json # TypeScript configuration
├── next.config.mjs # Next.js configuration
├── postcss.config.mjs # PostCSS configuration
└── eslint.config.mjs # ESLint configuration
\`\`\`

## 🚀 Getting Started

### Prerequisites

- Node.js 18+ or pnpm
- npm, yarn, or pnpm package manager

### Installation

1. **Clone or extract the project**
   \`\`\`bash
   cd weather
   \`\`\`

2. **Install dependencies**
   \`\`\`bash
   npm install

   # or

   pnpm install

   # or

   yarn install
   \`\`\`

3. **Run the development server**
   \`\`\`bash
   npm run dev

   # or

   pnpm dev

   # or

   yarn dev
   \`\`\`

4. **Open in browser**
   Navigate to [http://localhost:3000](http://localhost:3000)

### Build for Production

\`\`\`bash
npm run build
npm start
\`\`\`

## 📊 API Integration

The app uses the **Open-Meteo API** for weather data:

- **Endpoint**: `https://api.open-meteo.com/v1/forecast`
- **Authentication**: No API key required
- **Rate Limit**: 10,000 requests/day (free tier)
- **Data**: Current conditions, hourly forecasts (7 days), daily forecasts (16 days)

### Weather Code Mapping

The app uses WMO Weather Codes to determine weather conditions and display appropriate icons:

- 0: Clear sky
- 1-3: Partly cloudy
- 45-48: Foggy
- 51-67: Drizzle/Rain
- 71-77: Snow
- 80-82: Rain showers
- 85-86: Snow showers
- 95-99: Thunderstorms

## 🎨 Design System

### Color Palettes

The app features 5 dynamic color palettes that can be manually selected or automatically chosen based on temperature:

1. **Blue Palette**: Cool, calm aesthetic for cold weather
2. **Green Palette**: Fresh, balanced feel for cool weather
3. **Yellow Palette**: Warm, sunny appearance for warm weather
4. **Red Palette**: Hot, energetic theme for hot weather
5. **Purple Palette**: Alternative cool/calm theme

### Design Tokens

All colors are defined as CSS custom properties in `app/globals.css`:

- `--background`: Main background color
- `--foreground`: Primary text color
- `--card`: Card background color
- `--primary`: Primary brand color
- `--accent`: Accent color for highlights
- `--muted`: Muted text color
- `--border`: Border color
- And more...

### Typography

- **Font Family**: Poppins (Google Fonts)
- **Weights**: 400, 500, 600, 700
- **Headings**: Bold (700) for h1, h2; Semibold (600) for h3, h4
- **Body**: Regular (400) for paragraphs; Medium (500) for emphasis

## 🧩 Component Architecture

### Atomic Design Pattern

The project follows the Atomic Design methodology:

- **Atoms**: Basic UI elements (buttons, icons, cards)
- **Molecules**: Simple component combinations (search input, forecast cards)
- **Organisms**: Complex feature components (header, weather card, forecast section)
- **Templates**: Page-level layouts (weather page template)

### Key Components

#### `useWeather` Hook

Fetches weather data from Open-Meteo API. Manages loading and error states.

\`\`\`typescript
const { weather, loading, error } = useWeather(latitude, longitude)
\`\`\`

#### `WeatherPageTemplate`

Main page component that orchestrates all weather sections. Handles:

- Location state management
- Forecast type switching (hourly/daily)
- Color palette selection
- Data processing and transformation

#### `CurrentWeatherCard`

Displays current weather conditions with:

- Animated weather icon
- Temperature and "feels like" display
- Detailed metrics (wind, humidity, visibility, pressure, sunrise/sunset)

#### `ChartSection`

Interactive charts showing:

- Temperature trend (24 hours)
- Humidity levels
- Precipitation amounts
- Wind speed

#### `ForecastSection`

Tabbed interface for:

- Hourly forecast (next 12 hours)
- Daily forecast (next 7 days)

## 🎯 Key Features Explained

### Dynamic Color Theming

The app automatically selects a color palette based on current temperature:

\`\`\`typescript
const getThemeByTemperature = (temp: number): ColorPalette => {
if (temp < 10) return "blue";
if (temp < 20) return "green";
if (temp < 25) return "yellow";
return "red";
};
\`\`\`

Users can override this with manual selection via the theme color picker.

### Data Processing

Weather data from the API is processed into multiple formats:

- **Chart Data**: 24-hour hourly data for visualization
- **Hourly Forecast**: Next 12 hours with detailed metrics
- **Daily Forecast**: Next 7 days with min/max temperatures
- **Weekly Forecast**: Next 14 days for extended outlook

### Animations

The app uses Framer Motion for smooth animations:

- Component entrance animations (fade + slide)
- Floating weather icon effect
- Smooth transitions between states
- Hover effects on interactive elements

## 🔧 Configuration

### Environment Variables

Currently, the app doesn't require any environment variables as it uses the free Open-Meteo API.

### Tailwind Configuration

Tailwind CSS v4 is configured with:

- Custom design tokens in `globals.css`
- Responsive breakpoints (mobile-first)
- Custom animations and transitions
- Glassmorphism effects

### Next.js Configuration

- **App Router**: Using the modern Next.js 16 App Router
- **Turbopack**: Default bundler for faster builds
- **React Compiler**: Enabled for optimized rendering

## 📱 Responsive Design

The app is fully responsive with breakpoints:

- **Mobile**: < 640px (sm)
- **Tablet**: 640px - 1024px (md, lg)
- **Desktop**: > 1024px (xl, 2xl)

Layout adjusts automatically:

- Single column on mobile
- Multi-column on tablet/desktop
- Flexible spacing and sizing

## 🐛 Troubleshooting

### Weather data not loading

- Check internet connection
- Verify latitude/longitude values
- Check browser console for API errors
- Open-Meteo API might be temporarily unavailable

### Styling issues

- Clear `.next` folder and rebuild: `rm -rf .next && npm run build`
- Ensure Tailwind CSS is properly configured
- Check for conflicting CSS classes

### Performance issues

- Check browser DevTools Performance tab
- Verify no unnecessary re-renders
- Consider code splitting for large components

## 📚 Learning Resources

- [Next.js Documentation](https://nextjs.org/docs)
- [React Documentation](https://react.dev)
- [Tailwind CSS Documentation](https://tailwindcss.com/docs)
- [Framer Motion Documentation](https://www.framer.com/motion/)
- [Recharts Documentation](https://recharts.org/)
- [Open-Meteo API Documentation](https://open-meteo.com/en/docs)

## 📄 License

This project is open source and available under the MIT License.

## 👨‍💻 Author

**Kanak Verma** - Created this modern weather application as a showcase of modern web development practices with Next.js, React, and Tailwind CSS.

## 🤝 Contributing

Contributions are welcome! Feel free to:

- Report bugs
- Suggest features
- Submit pull requests
- Improve documentation

## 🎓 Development Notes

### Code Style

- TypeScript for type safety
- Functional components with hooks
- Atomic design pattern
- Consistent naming conventions
- Comments for complex logic

### Best Practices

- Server components where possible
- Client components only when needed
- Proper error handling
- Loading states for async operations
- Responsive design mobile-first
- Accessibility considerations (ARIA labels, semantic HTML)

### Performance Optimizations

- Image optimization with Next.js Image component
- Code splitting and lazy loading
- Efficient re-renders with React hooks
- CSS-in-JS with Tailwind for minimal bundle size
- Caching strategies for API calls

---

**Happy Weather Checking! 🌤️**

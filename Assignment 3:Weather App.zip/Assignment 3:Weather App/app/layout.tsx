import type React from "react";
import type { Metadata } from "next";
import { Poppins } from "next/font/google";
import "./globals.css";

const poppins = Poppins({
  weight: ["400", "500", "600", "700"],
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Verma Weather - Real-time Weather Insights",
  description: "Modern weather app with real-time data and forecasts",
  generator: "v0.app",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <link rel="icon" type="image/png" href="/favicon.png" />
      <body className={`${poppins.className} antialiased`}>{children}</body>
    </html>
  );
}

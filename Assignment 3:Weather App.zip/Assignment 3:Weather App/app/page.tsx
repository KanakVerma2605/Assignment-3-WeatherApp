"use client"

import WeatherPageTemplate from "@/components/templates/weather-page-template"

export default function Home() {
  return <WeatherPageTemplate />
}

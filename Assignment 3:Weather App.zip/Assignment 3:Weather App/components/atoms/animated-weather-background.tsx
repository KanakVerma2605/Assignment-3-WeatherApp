"use client"

import { motion } from "framer-motion"

interface AnimatedWeatherBackgroundProps {
  weatherCode: number
}

const RainBackground = () => (
  <svg className="absolute inset-0 w-full h-full" viewBox="0 0 1000 600" preserveAspectRatio="xMidYMid slice">
    <defs>
      <linearGradient id="rainGradient" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#64748b" stopOpacity="0.85" />
        <stop offset="50%" stopColor="#475569" stopOpacity="0.8" />
        <stop offset="100%" stopColor="#334155" stopOpacity="0.75" />
      </linearGradient>
      <filter id="rainBlur">
        <feGaussianBlur in="SourceGraphic" stdDeviation="1.5" />
      </filter>
    </defs>
    <rect width="1000" height="600" fill="url(#rainGradient)" />

    <motion.g
      animate={{ x: [-150, 150, -150] }}
      transition={{ duration: 12, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
    >
      <ellipse cx="150" cy="100" rx="120" ry="70" fill="rgba(148,163,184,0.6)" />
      <ellipse cx="280" cy="85" rx="140" ry="75" fill="rgba(128,145,164,0.55)" />
      <ellipse cx="380" cy="110" rx="110" ry="65" fill="rgba(148,163,184,0.5)" />
      <ellipse cx="480" cy="95" rx="130" ry="70" fill="rgba(128,145,164,0.45)" />
    </motion.g>

    {[...Array(25)].map((_, i) => (
      <motion.line
        key={i}
        x1={40 + i * 40}
        y1={80}
        x2={40 + i * 40}
        y2={130}
        stroke="rgba(255,255,255,0.7)"
        strokeWidth="2"
        strokeLinecap="round"
        animate={{ y1: [80, 580], y2: [130, 630], opacity: [0, 0.7, 0] }}
        transition={{
          duration: 2,
          repeat: Number.POSITIVE_INFINITY,
          delay: i * 0.06,
          ease: "linear",
        }}
      />
    ))}

    {[...Array(18)].map((_, i) => (
      <motion.line
        key={`rain-2-${i}`}
        x1={20 + i * 55}
        y1={150}
        x2={20 + i * 55}
        y2={190}
        stroke="rgba(255,255,255,0.4)"
        strokeWidth="1.5"
        strokeLinecap="round"
        animate={{ y1: [150, 580], y2: [190, 620], opacity: [0, 0.4, 0] }}
        transition={{
          duration: 2.5,
          repeat: Number.POSITIVE_INFINITY,
          delay: i * 0.08 + 0.3,
          ease: "linear",
        }}
      />
    ))}
  </svg>
)

const SunnyBackground = () => (
  <svg className="absolute inset-0 w-full h-full" viewBox="0 0 1000 600" preserveAspectRatio="xMidYMid slice">
    <defs>
      <linearGradient id="sunnyGradient" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#fef3c7" stopOpacity="0.9" />
        <stop offset="50%" stopColor="#fde68a" stopOpacity="0.85" />
        <stop offset="100%" stopColor="#fcd34d" stopOpacity="0.8" />
      </linearGradient>
      <radialGradient id="sunGlow" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="rgba(255,220,100,0.4)" />
        <stop offset="100%" stopColor="rgba(255,200,50,0)" />
      </radialGradient>
    </defs>
    <rect width="1000" height="600" fill="url(#sunnyGradient)" />

    <circle cx="850" cy="120" r="120" fill="url(#sunGlow)" />

    <motion.circle
      cx="850"
      cy="120"
      r="70"
      fill="rgba(255,200,50,0.95)"
      animate={{ opacity: [0.85, 0.95, 0.85] }}
      transition={{ duration: 5, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
    />

    <motion.g
      animate={{ rotate: 360 }}
      transition={{ duration: 30, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
      style={{ transformOrigin: "850px 120px" }}
    >
      {[...Array(12)].map((_, i) => (
        <line
          key={i}
          x1="850"
          y1="30"
          x2="850"
          y2="0"
          stroke="rgba(255,200,50,0.5)"
          strokeWidth="4"
          strokeLinecap="round"
          transform={`rotate(${i * 30} 850 120)`}
        />
      ))}
    </motion.g>
  </svg>
)

const SnowBackground = () => (
  <svg className="absolute inset-0 w-full h-full" viewBox="0 0 1000 600" preserveAspectRatio="xMidYMid slice">
    <defs>
      <linearGradient id="snowGradient" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#e0f2fe" stopOpacity="0.9" />
        <stop offset="50%" stopColor="#bae6fd" stopOpacity="0.85" />
        <stop offset="100%" stopColor="#7dd3fc" stopOpacity="0.8" />
      </linearGradient>
    </defs>
    <rect width="1000" height="600" fill="url(#snowGradient)" />

    {[...Array(25)].map((_, i) => (
      <motion.circle
        key={i}
        cx={40 + i * 40}
        cy={-50}
        r="5"
        fill="rgba(255,255,255,0.9)"
        animate={{
          y: [-50, 650],
          x: [40 + i * 40, 40 + i * 40 + Math.sin(i * 0.5) * 80],
          opacity: [0, 1, 0],
        }}
        transition={{
          duration: 5 + i * 0.15,
          repeat: Number.POSITIVE_INFINITY,
          delay: i * 0.12,
          ease: "easeIn",
        }}
      />
    ))}
  </svg>
)

const CloudyBackground = () => (
  <svg className="absolute inset-0 w-full h-full" viewBox="0 0 1000 600" preserveAspectRatio="xMidYMid slice">
    <defs>
      <linearGradient id="cloudyGradient" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#e5e7eb" stopOpacity="0.9" />
        <stop offset="50%" stopColor="#d1d5db" stopOpacity="0.85" />
        <stop offset="100%" stopColor="#9ca3af" stopOpacity="0.8" />
      </linearGradient>
    </defs>
    <rect width="1000" height="600" fill="url(#cloudyGradient)" />

    <motion.g
      animate={{ x: [-250, 250, -250] }}
      transition={{ duration: 14, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
    >
      <ellipse cx="150" cy="140" rx="160" ry="110" fill="rgba(255,255,255,0.5)" />
      <ellipse cx="320" cy="110" rx="190" ry="120" fill="rgba(255,255,255,0.45)" />
      <ellipse cx="520" cy="130" rx="170" ry="110" fill="rgba(255,255,255,0.4)" />
    </motion.g>

    <motion.g
      animate={{ x: [250, -250, 250] }}
      transition={{ duration: 16, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
    >
      <ellipse cx="600" cy="200" rx="150" ry="100" fill="rgba(255,255,255,0.3)" />
      <ellipse cx="780" cy="180" rx="170" ry="110" fill="rgba(255,255,255,0.25)" />
    </motion.g>
  </svg>
)

const FogBackground = () => (
  <svg className="absolute inset-0 w-full h-full" viewBox="0 0 1000 600" preserveAspectRatio="xMidYMid slice">
    <defs>
      <linearGradient id="fogGradient" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#f3f4f6" stopOpacity="0.9" />
        <stop offset="50%" stopColor="#e5e7eb" stopOpacity="0.85" />
        <stop offset="100%" stopColor="#d1d5db" stopOpacity="0.8" />
      </linearGradient>
    </defs>
    <rect width="1000" height="600" fill="url(#fogGradient)" />

    <motion.rect
      width="1000"
      height="600"
      fill="rgba(255,255,255,0.4)"
      animate={{ opacity: [0.2, 0.6, 0.2] }}
      transition={{ duration: 7, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
    />

    <motion.rect
      width="1000"
      height="600"
      fill="rgba(200,200,200,0.3)"
      animate={{ opacity: [0.3, 0.1, 0.3] }}
      transition={{ duration: 9, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut", delay: 1 }}
    />
  </svg>
)

export default function AnimatedWeatherBackground({ weatherCode }: AnimatedWeatherBackgroundProps) {
  const getBackground = () => {
    if (weatherCode === 0) return <SunnyBackground />
    if (weatherCode === 1 || weatherCode === 2 || weatherCode === 3) return <CloudyBackground />
    if (weatherCode >= 45 && weatherCode <= 48) return <FogBackground />
    if (weatherCode >= 51 && weatherCode <= 67) return <RainBackground />
    if (weatherCode >= 71 && weatherCode <= 77) return <SnowBackground />
    if (weatherCode >= 80 && weatherCode <= 82) return <RainBackground />
    if (weatherCode >= 85 && weatherCode <= 86) return <SnowBackground />
    if (weatherCode >= 80 && weatherCode <= 99) return <RainBackground />
    return <SunnyBackground />
  }

  return getBackground()
}

"use client"

import { motion } from "framer-motion"
import WeatherIcon from "./weather-icon"

interface DailyForecastCardProps {
  date: string
  weatherCode: number
  maxTemp: number
  minTemp: number
  wind: number
  precipitation: number
  index: number
  colors: { card: string; text: string; muted: string }
}

export default function DailyForecastCard({
  date,
  weatherCode,
  maxTemp,
  minTemp,
  wind,
  precipitation,
  index,
  colors,
}: DailyForecastCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.03 }}
      className={`bg-linear-to-br ${colors.card} rounded-lg p-3 border border-white/5 text-center backdrop-blur-sm`}
    >
      <p className={`text-xs ${colors.muted} mb-2`}>
        {new Date(date).toLocaleDateString("en-US", { weekday: "short" })}
      </p>
      <div className="flex justify-center mb-2">
        <WeatherIcon code={weatherCode} size={24} />
      </div>
      <div className="space-y-1 text-xs">
        <div>
          <p className={`text-sm font-semibold ${colors.text}`}>{Math.round(maxTemp)}°</p>
          <p className={colors.muted}>{Math.round(minTemp)}°</p>
        </div>
        <div className={`flex justify-between ${colors.muted}`}>
          <span>💨 {Math.round(wind)}km/h</span>
        </div>
        <div className={`flex justify-between ${colors.muted}`}>
          <span>🌧️ {precipitation.toFixed(1)}mm</span>
        </div>
      </div>
    </motion.div>
  )
}

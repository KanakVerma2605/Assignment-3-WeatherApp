"use client"

import { motion } from "framer-motion"

interface ForecastButtonProps {
  type: string
  isActive: boolean
  onClick: () => void
  colors: { text: string; muted: string }
}

export default function ForecastButton({ type, isActive, onClick, colors }: ForecastButtonProps) {
  return (
    <motion.button
      onClick={onClick}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className={`px-6 py-2 rounded-lg font-medium text-sm transition-all ${
        isActive
          ? `${colors.text} text-sm shadow-md border border-white/20`
          : `${colors.muted} bg-white/5 border border-white/10 hover:bg-white/10`
      }`}
    >
      {type.charAt(0).toUpperCase() + type.slice(1)}
    </motion.button>
  )
}

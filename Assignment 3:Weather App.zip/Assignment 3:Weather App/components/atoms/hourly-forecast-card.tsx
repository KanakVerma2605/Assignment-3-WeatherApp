"use client"

import { motion } from "framer-motion"
import WeatherIcon from "./weather-icon"

interface HourlyForecastCardProps {
  time: string
  temp: number
  weatherCode: number
  precipitation: number
  humidity: number
  wind: number
  index: number
  colors: { card: string; text: string; muted: string }
}

export default function HourlyForecastCard({
  time,
  temp,
  weatherCode,
  precipitation,
  humidity,
  wind,
  index,
  colors,
}: HourlyForecastCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.03 }}
      className={`bg-linear-to-br ${colors.card} rounded-lg p-3 border border-white/5 shrink-0 min-w-[130px] backdrop-blur-sm`}
    >
      <p className={`text-xs ${colors.muted} mb-2`}>{time}</p>
      <div className="flex justify-center mb-2">
        <WeatherIcon code={weatherCode} size={24} />
      </div>
      <p className={`text-lg font-semibold ${colors.text} mb-2`}>{temp}°</p>
      <div className="space-y-1 text-xs">
        <div className={`flex justify-between ${colors.muted}`}>
          <span>💧</span>
          <span>{humidity}%</span>
        </div>
        <div className={`flex justify-between ${colors.muted}`}>
          <span>💨</span>
          <span>{wind}km/h</span>
        </div>
        {precipitation > 0 && (
          <div className={`flex justify-between ${colors.muted}`}>
            <span>🌧️</span>
            <span>{precipitation.toFixed(1)}mm</span>
          </div>
        )}
      </div>
    </motion.div>
  )
}

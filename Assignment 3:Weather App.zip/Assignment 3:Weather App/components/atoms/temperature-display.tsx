"use client"

import { motion } from "framer-motion"

interface TemperatureDisplayProps {
  temperature: number
  feelsLike: number
  colors: { text: string; muted: string }
}

export default function TemperatureDisplay({ temperature, feelsLike, colors }: TemperatureDisplayProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center justify-center gap-3"
    >
      <div className="text-center">
        <div className={`text-5xl font-bold ${colors.text} mb-1`}>{Math.round(temperature)}°</div>
        <p className={`${colors.muted} text-sm`}>Feels like {Math.round(feelsLike)}°</p>
      </div>
    </motion.div>
  )
}

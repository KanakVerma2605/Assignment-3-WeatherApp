"use client"

import { motion } from "framer-motion"

interface ThemeColorButtonProps {
  color: string
  isActive: boolean
  onClick: () => void
  gradient: string
}

export default function ThemeColorButton({ color, isActive, onClick, gradient }: ThemeColorButtonProps) {
  return (
    <motion.button
      onClick={onClick}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
      className={`w-7 h-7 rounded-full border-2 transition-all ${
        isActive ? "border-white shadow-lg" : "border-white/30 hover:border-white/60"
      }`}
      style={{ background: gradient }}
      title={color}
    />
  )
}

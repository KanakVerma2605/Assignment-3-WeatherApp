import { Cloud, CloudRain, Sun, CloudSnow, CloudDrizzle, CloudFog } from "lucide-react"

interface WeatherIconProps {
  code: number
  size?: number
}

export default function WeatherIcon({ code, size = 24 }: WeatherIconProps) {
  const iconProps = { width: size, height: size }

  if (code === 0) return <Sun {...iconProps} className="text-yellow-400" />
  if (code === 1 || code === 2) return <Cloud {...iconProps} className="text-slate-400" />
  if (code === 3) return <Cloud {...iconProps} className="text-slate-500" />
  if (code >= 45 && code <= 48) return <CloudFog {...iconProps} className="text-slate-400" />
  if (code >= 51 && code <= 67) return <CloudDrizzle {...iconProps} className="text-blue-400" />
  if (code >= 71 && code <= 77) return <CloudSnow {...iconProps} className="text-blue-300" />
  if (code >= 80 && code <= 82) return <CloudRain {...iconProps} className="text-blue-500" />
  if (code >= 85 && code <= 86) return <CloudSnow {...iconProps} className="text-blue-300" />
  if (code >= 80 && code <= 99) return <CloudRain {...iconProps} className="text-blue-600" />
  return <Sun {...iconProps} className="text-yellow-400" />
}

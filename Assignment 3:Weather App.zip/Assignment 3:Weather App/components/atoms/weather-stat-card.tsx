import type { ReactNode } from "react"

interface WeatherStatCardProps {
  icon: ReactNode
  label: string
  value: string | number
  unit?: string
  colors: { text: string; muted: string }
}

export default function WeatherStatCard({ icon, label, value, unit, colors }: WeatherStatCardProps) {
  return (
    <div className="bg-white/5 rounded-lg p-3 border border-white/5">
      <div className={`flex items-center gap-2 ${colors.muted} mb-2`}>
        {icon}
        <span className="text-xs">{label}</span>
      </div>
      <p className={`text-xl font-semibold ${colors.text}`}>{value}</p>
      {unit && <p className={`text-xs ${colors.muted} mt-1`}>{unit}</p>}
    </div>
  )
}

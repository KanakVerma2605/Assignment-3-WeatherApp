"use client"

import { motion } from "framer-motion"
import WeatherIcon from "./weather-icon"

interface WeeklyForecastItemProps {
  date: string
  weatherCode: number
  maxTemp: number
  minTemp: number
  wind: number
  precipitation: number
  index: number
  colors: { card: string; text: string; muted: string }
}

export default function WeeklyForecastItem({
  date,
  weatherCode,
  maxTemp,
  minTemp,
  wind,
  precipitation,
  index,
  colors,
}: WeeklyForecastItemProps) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.3, delay: index * 0.02 }}
      className={`bg-linear-to-r ${colors.card} rounded-lg p-3 border border-white/5 flex items-center justify-between backdrop-blur-sm`}
    >
      <div className="flex items-center gap-3">
        <div className="shrink-0">
          <WeatherIcon code={weatherCode} size={28} />
        </div>
        <div>
          <p className={`font-semibold text-sm ${colors.text}`}>
            {new Date(date).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })}
          </p>
          <p className={`text-xs ${colors.muted}`}>
            💨 {Math.round(wind)}km/h • 🌧️ {precipitation.toFixed(1)}mm
          </p>
        </div>
      </div>
      <div className="flex items-center gap-4">
        <div className="text-right">
          <p className={`text-xs ${colors.muted}`}>High</p>
          <p className={`text-sm font-semibold ${colors.text}`}>{Math.round(maxTemp)}°</p>
        </div>
        <div className="text-right">
          <p className={`text-xs ${colors.muted}`}>Low</p>
          <p className={`text-sm font-semibold ${colors.muted}`}>{Math.round(minTemp)}°</p>
        </div>
      </div>
    </motion.div>
  )
}

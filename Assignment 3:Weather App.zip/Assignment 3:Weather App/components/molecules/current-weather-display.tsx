import { Wind, Droplets, Eye, Gauge, Sunrise } from "lucide-react";
import WeatherStatCard from "@/components/atoms/weather-stat-card";

interface CurrentWeatherDisplayProps {
  temperature: number;
  feelsLike: number;
  windSpeed: number;
  windDirection: number;
  humidity: number;
  visibility: number;
  pressure: number;
  sunrise: string;
  sunset: string;
  colors: { text: string; muted: string };
}

export default function CurrentWeatherDisplay({
  temperature,
  feelsLike,
  windSpeed,
  windDirection,
  humidity,
  visibility,
  pressure,
  sunrise,
  sunset,
  colors,
}: CurrentWeatherDisplayProps) {
  const getWindDirection = (degrees: number) => {
    const directions = [
      "N",
      "NNE",
      "NE",
      "ENE",
      "E",
      "ESE",
      "SE",
      "SSE",
      "S",
      "SSW",
      "SW",
      "WSW",
      "W",
      "WNW",
      "NW",
      "NNW",
    ];
    return directions[Math.round(degrees / 22.5) % 16];
  };

  return (
    <div className="grid grid-cols-2 gap-3">
      <WeatherStatCard
        icon={<Wind className="w-4 h-4" />}
        label="Wind"
        value={Math.round(windSpeed)}
        unit={`km/h ${getWindDirection(windDirection)}`}
        colors={colors}
      />

      <WeatherStatCard
        icon={<Droplets className="w-4 h-4" />}
        label="Humidity"
        value={`${humidity}%`}
        colors={colors}
      />

      <WeatherStatCard
        icon={<Eye className="w-4 h-4" />}
        label="Visibility"
        value={(visibility / 1000).toFixed(1)}
        unit="km"
        colors={colors}
      />

      <WeatherStatCard
        icon={<Gauge className="w-4 h-4" />}
        label="Pressure"
        value={pressure}
        unit="hPa"
        colors={colors}
      />

      <WeatherStatCard
        icon={<Sunrise className="w-4 h-4" />}
        label="Sunrise"
        value={new Date(sunrise).toLocaleTimeString("en-US", {
          hour: "2-digit",
          minute: "2-digit",
        })}
        colors={colors}
      />

      <WeatherStatCard
        icon={<Sunrise className="w-4 h-4" />}
        label="Sunset"
        value={new Date(sunset).toLocaleTimeString("en-US", {
          hour: "2-digit",
          minute: "2-digit",
        })}
        colors={colors}
      />
    </div>
  );
}

import DailyForecastCard from "@/components/atoms/daily-forecast-card"

interface DailyForecastGridProps {
  days: Array<{
    date: string
    weatherCode: number
    maxTemp: number
    minTemp: number
    wind: number
    precipitation: number
  }>
  colors: { card: string; text: string; muted: string }
}

export default function DailyForecastGrid({ days, colors }: DailyForecastGridProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-7 gap-3">
      {days.map((day, idx) => (
        <DailyForecastCard key={idx} index={idx} {...day} colors={colors} />
      ))}
    </div>
  )
}

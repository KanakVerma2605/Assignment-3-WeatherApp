"use client";

import ForecastButton from "@/components/atoms/forecast-button";

interface ForecastTabsProps {
  activeType: "hourly" | "daily";
  onTypeChange: (type: "hourly" | "daily") => void;
  colors: { text: string; muted: string };
}

export default function ForecastTabs({
  activeType,
  onTypeChange,
  colors,
}: ForecastTabsProps) {
  return (
    <div className="flex gap-2 mb-4">
      {(["hourly", "daily"] as const).map((type) => (
        <ForecastButton
          key={type}
          type={type}
          isActive={activeType === type}
          onClick={() => onTypeChange(type)}
          colors={colors}
        />
      ))}
    </div>
  );
}

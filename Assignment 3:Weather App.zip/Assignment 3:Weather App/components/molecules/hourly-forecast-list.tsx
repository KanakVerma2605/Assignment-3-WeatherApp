import HourlyForecastCard from "@/components/atoms/hourly-forecast-card"

interface HourlyForecastListProps {
  hours: Array<{
    time: string
    temp: number
    weatherCode: number
    precipitation: number
    humidity: number
    wind: number
  }>
  colors: { card: string; text: string; muted: string }
}

export default function HourlyForecastList({ hours, colors }: HourlyForecastListProps) {
  return (
    <div className="overflow-x-auto">
      <div className="flex gap-3 pb-2">
        {hours.map((hour, idx) => (
          <HourlyForecastCard key={idx} index={idx} {...hour} colors={colors} />
        ))}
      </div>
    </div>
  )
}

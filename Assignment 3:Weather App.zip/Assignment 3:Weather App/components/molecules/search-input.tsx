"use client";

import { useState } from "react";
import { Search } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface SearchInputProps {
  onLocationChange: (lat: number, lon: number, name: string) => void;
  colors: {
    bg: string;
    card: string;
    text: string;
    muted: string;
    accent: string;
  };
}

export default function SearchInput({
  onLocationChange,
  colors,
}: SearchInputProps) {
  console.log("colors: ", colors);
  const [input, setInput] = useState("");
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const handleSearch = async (value: string) => {
    setInput(value);
    if (value.length < 2) {
      setSuggestions([]);
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(
        `https://geocoding-api.open-meteo.com/v1/search?name=${value}&count=5&language=en&format=json`
      );
      const data = await response.json();
      setSuggestions(data.results || []);
    } catch (error) {
      console.error("Search error:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSelect = (result: any) => {
    onLocationChange(result.latitude, result.longitude, result.name);
    setInput("");
    setSuggestions([]);
  };

  return (
    <div className="relative w-full max-w-md">
      <div className="relative">
        <Search
          className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 ${colors.text}`}
        />
        <input
          type="text"
          value={input}
          onChange={(e) => handleSearch(e.target.value)}
          placeholder="Search location..."
          className={`w-full pl-10 pr-4 py-2.5 text-slate ${colors.text} backdrop-blur-md border border-white/10 rounded-lg text-foreground placeholder-slate-500 focus:outline-none transition-all duration-300`}
        />
      </div>

      <AnimatePresence>
        {suggestions.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className={`absolute top-full left-0 right-0 mt-2 bg-linear-to-br ${colors.bg} backdrop-blur-md border border-white/10 rounded-lg overflow-hidden shadow-lg z-50`}
          >
            {suggestions.map((result, idx) => (
              <button
                key={idx}
                onClick={() => handleSelect(result)}
                className={`w-full px-4 py-2.5 text-left hover:bg-white/10 transition-colors text-sm ${colors.text} border-b border-white/5 last:border-b-0`}
              >
                <div className="font-medium">{result.name}</div>
                <div className={`text-xs ${colors.text}`}>
                  {result.admin1 && `${result.admin1}, `}
                  {result.country}
                </div>
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

"use client"

import ThemeColorButton from "@/components/atoms/theme-color-button"

type ColorPalette = "blue" | "yellow" | "red" | "green" | "purple"

interface ThemeColorPickerProps {
  currentPalette: ColorPalette | null
  onPaletteChange: (palette: ColorPalette | null) => void
}

const colorGradients: Record<ColorPalette, string> = {
  blue: "linear-gradient(135deg, #1e3a8a, #0369a1)",
  yellow: "linear-gradient(135deg, #78350f, #b45309)",
  red: "linear-gradient(135deg, #7c2d12, #b91c1c)",
  green: "linear-gradient(135deg, #064e3b, #047857)",
  purple: "linear-gradient(135deg, #4c1d95, #7c3aed)",
}

export default function ThemeColorPicker({ currentPalette, onPaletteChange }: ThemeColorPickerProps) {
  return (
    <div className="flex gap-2">
      {(Object.keys(colorGradients) as ColorPalette[]).map((p) => (
        <ThemeColorButton
          key={p}
          color={p}
          isActive={currentPalette === p}
          onClick={() => onPaletteChange(currentPalette === p ? null : p)}
          gradient={colorGradients[p]}
        />
      ))}
    </div>
  )
}

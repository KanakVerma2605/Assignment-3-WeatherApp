import WeeklyForecastItem from "@/components/atoms/weekly-forecast-item"

interface WeeklyForecastListProps {
  days: Array<{
    date: string
    weatherCode: number
    maxTemp: number
    minTemp: number
    wind: number
    precipitation: number
  }>
  colors: { card: string; text: string; muted: string }
}

export default function WeeklyForecastList({ days, colors }: WeeklyForecastListProps) {
  return (
    <div className="grid grid-cols-1 gap-2">
      {days.map((day, idx) => (
        <WeeklyForecastItem key={idx} index={idx} {...day} colors={colors} />
      ))}
    </div>
  )
}

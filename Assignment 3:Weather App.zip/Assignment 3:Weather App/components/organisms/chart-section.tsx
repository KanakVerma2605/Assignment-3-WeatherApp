"use client"

import { motion } from "framer-motion"
import { Line, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Bar, ComposedChart } from "recharts"

interface ChartData {
  time: string
  temperature: number
  humidity: number
  precipitation: number
  wind: number
}

interface ChartSectionProps {
  chartData: ChartData[]
  colors: { card: string; text: string; muted: string }
}

const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-900/95 border border-slate-700 rounded-lg p-2 shadow-lg">
        <p className="text-xs text-slate-400">{payload[0].payload.time}</p>
        <p className="text-sm font-bold text-white">{payload[0].value}</p>
      </div>
    )
  }
  return null
}

export default function ChartSection({ chartData, colors }: ChartSectionProps) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.15 }}
        className={`bg-linear-to-br ${colors.card} border border-white/5 rounded-xl p-4 backdrop-blur-xl`}
      >
        <h3 className={`text-sm font-semibold ${colors.text} mb-3`}>Temperature & Wind</h3>
        <ResponsiveContainer width="100%" height={250}>
          <ComposedChart data={chartData}>
            <defs>
              <linearGradient id="colorTemp" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
            <XAxis dataKey="time" stroke="rgba(255,255,255,0.2)" style={{ fontSize: "11px" }} />
            <YAxis stroke="rgba(255,255,255,0.2)" style={{ fontSize: "11px" }} />
            <Tooltip content={<CustomTooltip />} />
            <Area type="monotone" dataKey="temperature" stroke="#3b82f6" fillOpacity={1} fill="url(#colorTemp)" />
            <Line type="monotone" dataKey="wind" stroke="#f59e0b" strokeWidth={2} dot={false} />
          </ComposedChart>
        </ResponsiveContainer>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className={`bg-linear-to-br ${colors.card} border border-white/5 rounded-xl p-4 backdrop-blur-xl`}
      >
        <h3 className={`text-sm font-semibold ${colors.text} mb-3`}>Humidity & Precipitation</h3>
        <ResponsiveContainer width="100%" height={250}>
          <ComposedChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
            <XAxis dataKey="time" stroke="rgba(255,255,255,0.2)" style={{ fontSize: "11px" }} />
            <YAxis stroke="rgba(255,255,255,0.2)" style={{ fontSize: "11px" }} yAxisId="left" />
            <YAxis stroke="rgba(255,255,255,0.2)" style={{ fontSize: "11px" }} yAxisId="right" orientation="right" />
            <Tooltip content={<CustomTooltip />} />
            <Line type="monotone" dataKey="humidity" stroke="#06b6d4" strokeWidth={2} dot={false} yAxisId="left" />
            <Bar dataKey="precipitation" fill="#3b82f6" radius={[4, 4, 0, 0]} yAxisId="right" />
          </ComposedChart>
        </ResponsiveContainer>
      </motion.div>
    </div>
  )
}

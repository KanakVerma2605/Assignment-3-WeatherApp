"use client";

import { motion } from "framer-motion";
import WeatherIcon from "@/components/atoms/weather-icon";
import CurrentWeatherDisplay from "@/components/molecules/current-weather-display";
import TemperatureDisplay from "../atoms/temperature-display";
import AnimatedWeatherBackground from "@/components/atoms/animated-weather-background";

interface CurrentWeatherCardProps {
  location: string;
  date: string;
  weatherCode: number;
  temperature: number;
  feelsLike: number;
  windSpeed: number;
  windDirection: number;
  humidity: number;
  visibility: number;
  pressure: number;
  sunrise: string;
  sunset: string;
  colors: { card: string; text: string; muted: string; accent: string };
}

// Main card displaying current weather conditions with animated elements
// Features animated weather icon, temperature display, and detailed weather metrics
export default function CurrentWeatherCard({
  location,
  date,
  weatherCode,
  temperature,
  feelsLike,
  windSpeed,
  windDirection,
  humidity,
  visibility,
  pressure,
  sunrise,
  sunset,
  colors,
}: CurrentWeatherCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className={`relative border border-white/5 rounded-xl p-6 backdrop-blur-xl overflow-hidden`}
    >
      {/* Animated background based on weather code */}
      <AnimatedWeatherBackground weatherCode={weatherCode} />

      {/* Dark overlay for better text readability */}
      <div className="absolute inset-0 bg-black/20 rounded-xl" />

      <div className="relative z-10">
        {/* Location and date header */}
        <div className="mb-6">
          <h2 className="text-xl font-semibold text-white">{location}</h2>
          <p className="text-sm text-white/80 mt-1">{date}</p>
        </div>

        {/* Two-column layout: weather icon + temperature on left, detailed metrics on right */}
        <div className="grid grid-cols-2">
          {/* Left column: animated weather icon and temperature */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="flex flex-col items-center justify-center gap-3"
          >
            {/* Animated floating effect on weather icon */}
            <motion.div
              animate={{ y: [0, -8, 0] }}
              transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
            >
              <WeatherIcon code={weatherCode} size={72} />
              <TemperatureDisplay
                temperature={temperature}
                feelsLike={feelsLike}
                colors={{
                  ...colors,
                  text: "text-white",
                  muted: "text-white/60",
                }}
              />
            </motion.div>
          </motion.div>

          {/* Right column: detailed weather metrics (wind, humidity, visibility, pressure, sunrise/sunset) */}
          <CurrentWeatherDisplay
            temperature={temperature}
            feelsLike={feelsLike}
            windSpeed={windSpeed}
            windDirection={windDirection}
            humidity={humidity}
            visibility={visibility}
            pressure={pressure}
            sunrise={sunrise}
            sunset={sunset}
            colors={{ ...colors, text: "text-white", muted: "text-white/60" }}
          />
        </div>
      </div>
    </motion.div>
  );
}

"use client";

import { motion } from "framer-motion";
import ForecastTabs from "@/components/molecules/forecast-tabs";
import HourlyForecastList from "@/components/molecules/hourly-forecast-list";
import WeeklyForecastList from "@/components/molecules/weekly-forecast-list";

type ForecastType = "hourly" | "daily";

interface ForecastSectionProps {
  forecastType: ForecastType;
  onForecastTypeChange: (type: ForecastType) => void;
  hourlyData: Array<{
    time: string;
    temp: number;
    weatherCode: number;
    precipitation: number;
    humidity: number;
    wind: number;
  }>;
  dailyData: Array<{
    date: string;
    weatherCode: number;
    maxTemp: number;
    minTemp: number;
    wind: number;
    precipitation: number;
  }>;
  colors: { card: string; text: string; muted: string };
}

export default function ForecastSection({
  forecastType,
  onForecastTypeChange,
  hourlyData,
  dailyData,
  colors,
}: ForecastSectionProps) {
  const renderForecastContent = () => {
    if (forecastType === "hourly") {
      return <HourlyForecastList hours={hourlyData} colors={colors} />;
    }
    if (forecastType === "daily") {
      return <WeeklyForecastList days={dailyData} colors={colors} />;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.25 }}
      className={`bg-linear-to-br ${colors.card} border border-white/5 rounded-xl p-4 backdrop-blur-xl`}
    >
      <h3 className={`text-sm font-semibold ${colors.text} mb-4`}>Forecast</h3>
      <ForecastTabs
        activeType={forecastType}
        onTypeChange={onForecastTypeChange}
        colors={colors}
      />
      {renderForecastContent()}
    </motion.div>
  );
}

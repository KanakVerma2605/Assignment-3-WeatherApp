"use client";

import { motion } from "framer-motion";
import SearchInput from "@/components/molecules/search-input";
import ThemeColorPicker from "@/components/molecules/theme-color-picker";

type ColorPalette = "blue" | "yellow" | "red" | "green" | "purple";

interface HeaderProps {
  onLocationChange: (lat: number, lon: number, name: string) => void;
  currentPalette: ColorPalette | null;
  onPaletteChange: (palette: ColorPalette | null) => void;
  colors: {
    bg: string;
    card: string;
    text: string;
    muted: string;
    accent: string;
  };
}

// Header component with app title, search input, and theme color picker
// Sticky positioning keeps it visible while scrolling
export default function Header({
  onLocationChange,
  currentPalette,
  onPaletteChange,
  colors,
}: HeaderProps) {
  return (
    <header
      className={`border-b border-white/5 sticky top-0 z-40 bg-linear-to-br ${colors.bg}`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          {/* App title with animated entrance */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1
              className={`text-2xl font-bold bg-linear-to-r ${colors.accent} bg-clip-text text-transparent`}
            >
              Verma Weather
            </h1>
            <p className="text-xs text-slate-500 mt-0.5">by Kanak Verma</p>
          </motion.div>

          {/* Search input for location changes */}
          <SearchInput onLocationChange={onLocationChange} colors={colors} />

          {/* Theme color picker for manual palette selection */}
          <ThemeColorPicker
            currentPalette={currentPalette}
            onPaletteChange={onPaletteChange}
          />
        </div>
      </div>
    </header>
  );
}

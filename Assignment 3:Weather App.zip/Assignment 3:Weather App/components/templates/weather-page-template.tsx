"use client";

import { useState } from "react";
import { useWeather } from "@/hooks/use-weather";
import Header from "@/components/organisms/header";
import CurrentWeatherCard from "@/components/organisms/current-weather-card";
import ChartSection from "@/components/organisms/chart-section";
import ForecastSection from "@/components/organisms/forecast-section";

// Type definitions for forecast display and color themes
type ForecastType = "hourly" | "daily";
type ColorPalette = "blue" | "yellow" | "red" | "green" | "purple";

// Color palette definitions for different temperature ranges
// Each palette includes background, card, text, muted, and accent colors
const colorPalettes: Record<
  ColorPalette,
  { bg: string; card: string; text: string; muted: string; accent: string }
> = {
  blue: {
    bg: "from-blue-100 to-blue-200",
    card: "from-blue-50 to-blue-100",
    text: "text-blue-900",
    muted: "text-blue-500",
    accent: "from-blue-400 to-blue-500",
  },
  yellow: {
    bg: "from-amber-100 to-amber-200",
    card: "from-amber-50 to-amber-100",
    text: "text-amber-900",
    muted: "text-amber-600",
    accent: "from-amber-400 to-amber-500",
  },
  red: {
    bg: "from-rose-100 to-rose-200",
    card: "from-rose-50 to-rose-100",
    text: "text-rose-900",
    muted: "text-rose-500",
    accent: "from-rose-400 to-rose-500",
  },
  green: {
    bg: "from-emerald-100 to-emerald-200",
    card: "from-emerald-50 to-emerald-100",
    text: "text-emerald-900",
    muted: "text-emerald-600",
    accent: "from-emerald-400 to-emerald-500",
  },
  purple: {
    bg: "from-violet-100 to-violet-200",
    card: "from-violet-50 to-violet-100",
    text: "text-violet-900",
    muted: "text-violet-600",
    accent: "from-violet-400 to-violet-500",
  },
};

interface WeatherPageTemplateProps {
  initialLat?: number;
  initialLon?: number;
  initialName?: string;
}

export default function WeatherPageTemplate({
  initialLat = -37.8136,
  initialLon = 144.9631,
  initialName = "Melbourne, Australia",
}: WeatherPageTemplateProps) {
  // State management for location, forecast type, and color palette
  const [location, setLocation] = useState({
    lat: initialLat,
    lon: initialLon,
    name: initialName,
  });
  const [forecastType, setForecastType] = useState<ForecastType>("hourly");
  const [palette, setPalette] = useState<ColorPalette | null>(null);

  // Fetch weather data using the custom hook
  const { weather, loading, error } = useWeather(location.lat, location.lon);

  // Function to determine color theme based on temperature
  // Cold (<10°C) = blue, Cool (10-20°C) = green, Warm (20-25°C) = yellow, Hot (>25°C) = red
  const getThemeByTemperature = (temp: number): ColorPalette => {
    if (temp < 10) return "blue";
    if (temp < 20) return "green";
    if (temp < 25) return "yellow";
    return "red";
  };

  // Determine current theme: use manual selection if available, otherwise auto-select based on temperature
  const currentTheme =
    palette ||
    (weather ? getThemeByTemperature(weather.current.temperature_2m) : "blue");
  const colors = colorPalettes[currentTheme];

  // Handler for location changes from search input
  const handleLocationChange = (lat: number, lon: number, name: string) => {
    setLocation({ lat, lon, name });
  };

  // Loading state UI
  if (!weather) {
    return (
      <main
        className={`min-h-screen bg-linear-to-br ${colors.bg} flex items-center justify-center`}
      >
        <div className="animate-spin rounded-full h-12 w-12 border-2 border-slate-700 border-t-slate-400" />
      </main>
    );
  }

  // Extract current, hourly, and daily weather data
  const current = weather.current;
  const hourly = weather.hourly;
  const daily = weather.daily;
  const now = new Date();
  const currentHourIndex = now.getHours();

  // Process hourly chart data for the next 24 hours
  const chartData = Array.from({ length: 24 }).map((_, i) => {
    const index = (currentHourIndex + i) % 24;
    const time = new Date(now);
    time.setHours(index);
    return {
      time: time.toLocaleTimeString("en-US", { hour: "2-digit" }),
      temperature: Math.round(hourly.temperature_2m[index]),
      humidity: hourly.relative_humidity_2m[index],
      precipitation: hourly.precipitation[index] || 0,
      wind: Math.round(hourly.wind_speed_10m[index]),
    };
  });

  // Process next 12 hours forecast data
  const nextHours = Array.from({ length: 12 }).map((_, i) => {
    const index = (currentHourIndex + i) % 24;
    const time = new Date(now);
    time.setHours(index);
    return {
      time: time.toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit",
      }),
      temp: Math.round(hourly.temperature_2m[index]),
      weatherCode: hourly.weather_code?.[index] || 0,
      precipitation: hourly.precipitation[index] || 0,
      humidity: hourly.relative_humidity_2m[index],
      wind: Math.round(hourly.wind_speed_10m[index]),
    };
  });

  // Process daily forecast for the next 7 days
  const dailyForecast = daily.time
    .slice(0, 7)
    .map((date: string, idx: number) => ({
      date,
      weatherCode: daily.weather_code[idx],
      maxTemp: daily.temperature_2m_max[idx],
      minTemp: daily.temperature_2m_min[idx],
      wind: daily.wind_speed_10m_max[idx],
      precipitation: daily.precipitation_sum[idx],
    }));

  // Process weekly forecast for the next 14 days
  const weeklyForecast = daily.time
    .slice(0, 14)
    .map((date: string, idx: number) => ({
      date,
      weatherCode: daily.weather_code[idx],
      maxTemp: daily.temperature_2m_max[idx],
      minTemp: daily.temperature_2m_min[idx],
      wind: daily.wind_speed_10m_max[idx],
      precipitation: daily.precipitation_sum[idx],
    }));

  return (
    <main className={`min-h-screen bg-linear-to-br ${colors.bg}`}>
      {/* Decorative background blur elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-white/3 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-white/3 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10">
        {/* Header with search and theme picker */}
        <Header
          onLocationChange={handleLocationChange}
          currentPalette={palette}
          onPaletteChange={setPalette}
          colors={colors}
        />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
          {/* Error message display */}
          {error && (
            <div
              className={`bg-white/5 border border-white/10 rounded-lg p-3 text-sm ${colors.text}`}
            >
              {error}
            </div>
          )}

          {/* Loading spinner */}
          {loading && (
            <div className="flex items-center justify-center py-20">
              <div className="animate-spin rounded-full h-12 w-12 border-2 border-slate-700 border-t-slate-400" />
            </div>
          )}

          {/* Main weather content sections */}
          {weather && !loading && (
            <>
              {/* Current weather card with detailed information */}
              <CurrentWeatherCard
                location={location.name}
                date={new Date().toLocaleDateString("en-US", {
                  weekday: "long",
                  month: "long",
                  day: "numeric",
                })}
                weatherCode={current.weather_code}
                temperature={current.temperature_2m}
                feelsLike={current.temperature_2m - 2}
                windSpeed={current.wind_speed_10m}
                windDirection={current.wind_direction_10m}
                humidity={current.relative_humidity_2m}
                visibility={current.visibility}
                pressure={current.surface_pressure}
                sunrise={daily.sunrise[0]}
                sunset={daily.sunset[0]}
                colors={colors}
              />

              {/* Chart section showing temperature, humidity, precipitation, and wind trends */}
              <ChartSection chartData={chartData} colors={colors} />

              {/* Forecast section with hourly and daily tabs */}
              <ForecastSection
                forecastType={forecastType}
                onForecastTypeChange={setForecastType}
                hourlyData={nextHours}
                dailyData={dailyForecast}
                colors={colors}
              />
            </>
          )}
        </div>
      </div>
    </main>
  );
}
